/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package za.ac.tut.bl;

import java.util.Random;
import javax.ejb.Stateless;

/**
 *
 * @author THEKISO MTSHANYELO
 */
@Stateless
public class PredictionSB implements PredictionSBLocal {

    @Override
    public Integer isCorrect() {

        Random random = new Random();

        return random.nextInt(5);
    }
    
    
    @Override
    public double totalAmount(double amount) {

        return amount * 10;
    }
    
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
