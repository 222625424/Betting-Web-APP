/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.PageContext;
import za.ac.tut.bl.PredictionSBLocal;

/**
 *
 * @author THEKISO MTSHANYELO
 */
public class PredictionServlet extends HttpServlet {

    @EJB
    PredictionSBLocal psl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String siri = request.getServletContext().getInitParameter("name");
        String username = request.getParameter("username");
        Integer team1 = Integer.parseInt(request.getParameter("team_one"));
        Integer team2 = Integer.parseInt(request.getParameter("team_two"));
        double amount = Integer.parseInt(request.getParameter("amount"));
        double totalAmount = 0.0;
        String results;
        Integer teamOne = psl.isCorrect();
        Integer teamTwo = psl.isCorrect();
        
        if ((teamOne == team1) && (teamTwo == team2)) {
            totalAmount = amount * 10;
            results = "Won";
        } else {
            totalAmount = 0.0;
            results = "Lost";
        }

        request.setAttribute("siri", siri);
        request.setAttribute("username", username);
        request.setAttribute("team1", team1);
        request.setAttribute("team2", team2);
        request.setAttribute("team_one", teamOne);
        request.setAttribute("team_two", teamTwo);
        request.setAttribute("total_amount", totalAmount);
        request.setAttribute("results", results);

        RequestDispatcher disp = request.getRequestDispatcher("predict_score_outcome.jsp");
        disp.forward(request, response);
    }

}
